
function mudarTexto() {
    var paragrafo = document.getElementById("demo");
    paragrafo.innerHTML = "Texto alterado com sucesso!";
}
